# -*- coding: utf-8 -*-
"""
Created on Sun Jun 13 11:52:03 2021

@author: alex
"""
import pandas as pd
import glob

files = list(glob.glob("C:/Users/alex/Documents/source/*.csv"))

with open("C:/Users/alex/Documents/target/all_tweets.csv", "w") as outfile:
    for file in files:
        with open(file) as infile:
            contents = infile.read()
            outfile.write(contents)

t_sent = pd.read_csv('C:/Users/alex/Documents/target/all_tweets.csv', sep=",", index_col=False) 


def create_lable(polarity):
#    polarity = float(polarity)
    if polarity < 0:
        return "Negative"
    elif polarity == 0:
        return "Neutral"
    else:
        return "Positive"

t_sent['lable'] = t_sent.sentiment.apply(create_lable)
t_sent = t_sent.drop(['sentiment'], axis=1)

t_sent.to_csv('C:/Users/alex/Documents/target/all_tweets_with_lable.csv', sep=",", index=False)

