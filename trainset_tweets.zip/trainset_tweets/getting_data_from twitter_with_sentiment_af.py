# -*- coding: utf-8 -*-
"""
Twitter Streaming API
Created on Dec 08 2020
@author: alex
"""

# Code for Streaming used from "joelgrus" f"https://api.github.com/users/{github_user}/repos"

# pip install twython    
# from twython import Twython
# pip install textblob
# pip install tweet-preprocessor

from twython import TwythonStreamer
import pandas as pd
from textblob import TextBlob
import preprocessor as p

# My key and secret
CONSUMER_KEY = 'XP9WEtNESINs3LfjkyFYLIN8l'
CONSUMER_SECRET = 'VeVcYCxyGNJHAq5mwzJZXiAfioXeAajhrcQBYcU1uDjPShqmCS'
ACCESS_TOKEN = '1126001584830390272-JnhR5hrvd0YX9tnIpBTj3uNkhx3tsW'
ACCESS_TOKEN_SECRET = 'yLXT7Tcsr0Xx7T7ldUfyHs8Eltrro18gVWnBm0Xo2Q54m'


# Functions for Streaming
del(tweets, twitter_df)
tweets = [] 

class MyStreamer(TwythonStreamer):
    def on_success(self, data):
        """
        data in Python dict representing a tweet
        """
        # We only want to collect English-language tweets
        if data.get('lang') == 'en':
            tweets.append(data)
            if (len(tweets) % 10) == 0:
              print(f"received tweet #{len(tweets)}")

		# Stop when we've collected enough
        if len(tweets) >= 1000:
            self.disconnect()
        return tweets

    def on_error(self, status_code, data):
        print(status_code, data)
        self.disconnect()


# Functions for data extraction
def tcontent(stream):
    # Preprocessing options used for p.clean() below
    p.set_options(p.OPT.URL, p.OPT.EMOJI, p.OPT.SMILEY)
    textList = []
    for tweet in tweets:   
        textList.append(p.clean(tweet['text']))
    return textList

def sentiment(stream):
    dateList = []
    for tweet in tweets:   
        dateList.append(TextBlob(tweet['text']).sentiment.polarity)
    return dateList

def tnames(stream):
    nameList = []
    for tweet in tweets:   
        nameList.append(tweet['user']['name'])
    return nameList

def tdate(stream):
    dateList = []
    for tweet in tweets:   
        dateList.append(tweet['created_at'])
    return dateList


# Define the filter criteria
selection = ['Bitcoin', 'bitcoin']


# Consume public tweets with selection and create pandas dataframe
stream = MyStreamer(CONSUMER_KEY, CONSUMER_SECRET,
					ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

stream.statuses.filter(track=selection)
twitter_df = pd.concat([pd.Series(tcontent(tweets)), 
                        pd.Series(sentiment(tweets))],
                        axis=1)
twitter_df.columns = ['text', 'sentiment']

# Get rid of Rows with no Polarity
# twitter_df = twitter_df[twitter_df['sentiment'] != 0]


# Save dataframe 
path_to_save = "C:/Users/alex/Documents/source"
twitter_df.to_csv(path_to_save + '/twitter_sentiment1.csv', index=False, sep=",")



''' Experimental code

# Display the first tweet in the list
tweets[0]
pd.set_option('display.max_colwidth', 80)
print(twitter_df.iloc[0:10,0])

import json
tweetIndent = json.dumps(tweets[0], indent=4, sort_keys=False)
print(tweetIndent)


# testing the textblob function
test1 = str(twitter_df.at[0,2])
test2 = str(twitter_df.at[1,2])
print(test1)
TextBlob(test1).sentiment.polarity


mySample = tweets[30]
mySample['user']['name']
mySample.get('user', 'no user').get('name', 'no name')


'''
    

